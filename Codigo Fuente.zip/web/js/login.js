function accederListaPubli() {
	window.location = "../lista_publicaciones/lista_publicaciones.jsp";
}