Hemos estructurado el proyecto dividiendo los ficheros en varias carpetas:

	css: contiene los archivos css de cada uno de los wireframes.

	js: contiene los diferentes archivos javascript.

	html: contiene los ficheros html de cada uno de los wireframes.

	img: contiene las imágenes utilizadas en los wireframes.

	quill: contiene los ficheros necesarios para la utilización del editor Quill.

El documento pdf se encuentra en el directorio raiz junto a este txt
