function accederListaPubli() {
	window.location = "../html/WF5-lista_publicaciones.html";
}